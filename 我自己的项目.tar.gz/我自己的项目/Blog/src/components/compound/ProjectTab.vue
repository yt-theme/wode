<!-- can move -->
<template>
  <div class="ProjectTab-container" ref="ProjectT">
      <div @mousedown="tabHandleMouseDown($event)" class="ProjectTab-container-header">音乐</div>
      <div class="searchBox">
        <div class="search">
          <input v-model="searchInput" placeholder="搜索" @keyup="musicSearch()" v-on:click="clearSearch()"></input>
          <div class="searchRes">
            <ul>
              <li v-for="item in searchResData" v-on:click="getSongId($event)" v-bind:value="item.id">
                {{ item.name }} - {{ item.id }}
              </li>
            </ul>
          </div>
          <section class="player" v-html="playData"></section>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios'
import VueAxios from 'vue-axios'
export default {
  name: 'ProjectTab',
  data () {
    return {
      searchInput: '',
      searchResData: null,
      songId: '',
      playData: '',
      lyric: '',
    }
  },
  methods: {
    tabHandleMouseDown: function($event) {
      let e = $event.target
      e.style.zIndex            = "99999"
      e.parentNode.style.zIndex = "99999"
      let ProjectT  = this.$refs.ProjectT
      let startX  = $event.clientX-ProjectT.offsetLeft
      let startY  = $event.clientY-ProjectT.offsetTop
      this.startX = startX
      this.startY = startY
      this.ProjectT = ProjectT
      this.ProjectT.onmousemove = this.tabHandleMouseMove
      document.onmouseup      = this.tabHandleMouseUp
    },
    tabHandleMouseMove: function(e) {
      this.ProjectT.style.left = e.clientX-this.startX+"px"
      this.ProjectT.style.top  = e.clientY-this.startY+"px"
    },
    tabHandleMouseUp: function() {
      this.ProjectT.onmousemove = null
      this.ProjectT.onmouseup   = null
    },
    // search music
    musicSearch: function() {
      let s = () => {
        let keyword = this.searchInput
        const API_PROXY = 'https://bird.ioliu.cn/v1/?url=' //代理解决跨域
        const searchWord = 'http://music.163.com'
        axios.post(API_PROXY + searchWord + '/api/search/suggest/web' + '?s=' + keyword + '&limit=100')
        .then((res)=>{
          this.searchResData = res.data.result.songs
          // console.log(this.searchResData)
        })
      }
      setTimeout(s,200)
    },
    // get song id
    getSongId: function($event) {
      // song id
      this.songId = $event.target.attributes.value.value
      this.playSong(this.songId)
      this.clearSearch()
    },
    // play
    playSong: function() {
      // const API_PROXY = 'https://bird.ioliu.cn/v1/?url=' //代理解决跨域
      // const playWord = 'http://music.163.com/outchain/player?type=2&id=516392300'
      // axios.post(API_PROXY + playWord + '?id=' + id)
      // .then((res)=>{
      //   this.playData = res.data
      //   console.log(this.playData)
      // })
      this.playData = `<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=279 height=86 src="//music.163.com/outchain/player?type=2&id=${this.songId}&auto=1&height=66"></iframe>`
      // draw lyric
      const API_PROXY = 'https://bird.ioliu.cn/v1/?url=' //代理解决跨域
      const playWord = 'http://music.163.com/api/song/lyric?os=pc&'
      axios.post(API_PROXY + playWord + 'id=' + this.songId)
      .then((res)=>{
        // this.lyric = res.data
        console.log(res.data)
      })
    },
    // clear search data
    clearSearch: function() {
      this.searchResData = null
    }
  }
}
</script>
<style scoped>
.ProjectTab-container {
  display: flex;
  justify-content: center;
  padding-top: 50px;
  position: absolute;
  width: 12vw;
  min-width: 300px;
  height: 50vh;
  min-height: 180px;
  border: 3px solid #113337;
  background-color: #489799;
  overflow: auto; /* 加上overflow鼠标离开事件源神奇不影响事件生存 */
  box-shadow: 0 0 14px #113337;
  overflow: hidden;
}
.ProjectTab-container-header {
  position: absolute;
  top: 0;
  width: 100%;
  height: 3%;
  min-height: 25px;
  background-color: #113337;
  cursor: move;
  text-align: center;
  color: #B0B6B7;
}
.search> input {
  min-width: 279px;
  outline: none;
  border: 0;
  height: 2.1em;
  padding: 0.5em;
  background-color: #00292F;
  color: #b0b4b4;
  border-radius: 4px;
  margin-bottom: 2px;
}
.searchBox {
  width: 279px;
  position: relative;
  margin: 0 auto;
}
.searchRes {
  float: left;
  width: 279px;
  height: auto;
  max-height: 200px;
  background: url("../../assets/bgi.png") center center;
  overflow: auto;
  border-radius: 4px;
}
.searchRes> ul> li {
  margin: 0;
  padding: 0;
  line-height: 2em;
  overflow: auto;
  color: #b0b4b4;
  padding: 0.5em;
  cursor: pointer;
  border-bottom: 2px solid #489799;
  border-radius: 4px;
}
.player {
  margin: auto;
}
</style>
