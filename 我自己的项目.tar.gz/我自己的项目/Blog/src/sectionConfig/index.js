const config = {
  data: [
    {
      name: "我的笔记",
      logo: require('../assets/note.svg'),
      link: "https://yt-theme.github.io/MyGitBook/"
    },
    {
      name: "cnode",
      logo: require('../assets/form.svg'),
      link: "https://yt-theme.github.io/cnode-pc1"
    },
    {
      name: "oo",
      logo: require('../assets/kaka.svg'),
      link: "https://yt-theme.github.io/kaka/"
    },
    {
      name: "洛神云",
      logo: require('../assets/vps.svg'),
      link: "https://yt-theme.github.io/mcpanl/"
    },
    {
      name: "云的世界",
      logo: require('../assets/cloud.svg'),
      link: "https://yt-theme.github.io/mcpanlHomePage/"
    },
    {
      name: "just 4 fun",
      logo: require('../assets/j4f.svg'),
      link: "https://github.com/yt-theme/weavesilk"
    }
  ]
}
export default config
