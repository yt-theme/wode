// let readFiles = new FileReader()
// console.log(readFiles)
// readFiles.onload = function () {
//   readFiles.readAsText()
// }
const mk = [
  "> my Note",
  "时间 : 18.3.6",
  "```",
  "let a = 1",
  "```",
  "> 20180308",
  "> 原始版本 https://yt-theme.github.io/HelloWorld",
  "20180324修改"
]
export default mk
